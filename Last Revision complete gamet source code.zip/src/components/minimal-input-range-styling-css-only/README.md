# Minimal input range styling (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/renaudtertrais/pen/waLXVx](https://codepen.io/renaudtertrais/pen/waLXVx).

