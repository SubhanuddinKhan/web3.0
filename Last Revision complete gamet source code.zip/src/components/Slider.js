import React from 'react'
import './Slider.css';

function Slider() {
  return (
    <div>
    
    <input type="range" />
 
    </div>
  )
}

export default Slider